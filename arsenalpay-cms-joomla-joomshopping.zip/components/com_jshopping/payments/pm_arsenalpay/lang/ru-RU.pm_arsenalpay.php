<?php
define('_JSHOP_ARS_UNIQUE_ID','Уникальный токен ');
define('_JSHOP_ARS_UNIQUE_ID_TIP','Присваивается инетернет-магазину для работы с фреймом.');
define('_JSHOP_ARS_FRAME_URL','URL-адрес фрейма');
define('_JSHOP_ARS_FRAME_URL_TIP','УРЛ-адрес платежного фрейма ArsenalPay');
define('_JSHOP_ARS_PAYMENT_SRC','Тип платежа');
define('_JSHOP_ARS_PAYMENT_SRC_TIP','Возможные варианты: mk - оплата с мобильного телефона (мобильная коммерция), card - оплата с пластиковой карты (интернет эквайринг).');
define('_JSHOP_ARS_ALLOWED_IP','Разрешенный IP-адрес');
define('_JSHOP_ARS_ALLOWED_IP_TIP','С которого возможны обратные запросы о подтверждении платежей от ArsenalPay.');
define('_JSHOP_ARS_SIGN_KEY','Ключ (key)');
define('_JSHOP_ARS_SIGN_KEY_TIP','Для проверки подписи запросов. Обязательный');
define('_JSHOP_ARS_CSS_URL','Параметр css');
define('_JSHOP_ARS_CSS_URL_TIP','Aдрес (URL) CSS файла.');

define('_JSHOP_ARS_FRAME_MODE','Режим отображения фрейма');
define('_JSHOP_ARS_FRAME_MODE_TIP','"1" - отображать во фрейме, иначе на всю страницу');
define('_JSHOP_ARS_CHECK_URL','УРЛ проверки номера получателя');
define('_JSHOP_ARS_CALLBACK_URL','УРЛ колбэка платежа');
define('_JSHOP_ARS_RETURN_URL','URL возврата в случае успешной оплаты');
define('_JSHOP_ARS_CANCEL_URL','URL возврата в случае неуспешной оплаты');
define('_JSHOP_ARS_STATUS_END','Статус заказа для успешных транзакций.');
define('_JSHOP_ARS_STATUS_PENDING','Статус заказа для незавершенных транзакций.');
define('_JSHOP_ARS_STATUS_FAILED','Статус заказа для неуспешных транзакций.');

define('_JSHOP_ARS_FRAME_PARAMS_SECTION', 'Параметры отображения платежного фрейма');
define('_JSHOP_ARS_FRAME_WIDTH','width');
define('_JSHOP_ARS_FRAME_HEIGHT','height');
define('_JSHOP_ARS_FRAME_BORDER','frameborder');
define('_JSHOP_ARS_FRAME_SCROLLING','scrolling');
define('_JSHOP_ARS_REQUIRED_TEXT','Обязательные поля');
?>